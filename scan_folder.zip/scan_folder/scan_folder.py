#!/usr/bin/env python3
"""
Generate a tree-like folder structure text file for a given directory,
ignoring:
 - any file or folder whose name starts with a full stop (dot),
 - any directory named exactly "node_modules" (and its children).

Files will include their size in bytes next to their name.

Usage:
    python folder_tree.py
"""

import sys
from pathlib import Path
from typing import List, Optional, Union

# Characters used for drawing the tree
INDENT = "│   "
BRANCH = "├── "
LAST = "└── "

# Names to ignore
IGNORE_PREFIX = "."           # ignore entries starting with this prefix
IGNORED_DIR_NAMES = {"node_modules"}


def should_ignore(entry: Path) -> bool:
    """
    Return True if the entry should be ignored:
      - name starts with IGNORE_PREFIX (e.g., dotfiles/folders)
      - entry is a directory and its name is in IGNORED_DIR_NAMES
    """
    name = entry.name
    if name.startswith(IGNORE_PREFIX):
        return True
    if entry.is_dir() and name in IGNORED_DIR_NAMES:
        return True
    return False


def iter_entries(path: Path) -> List[Path]:
    """
    Return a sorted list of entries for path, excluding ignored names.
    Directories come before files. Sort is case-insensitive.
    """
    try:
        entries = [p for p in path.iterdir() if not should_ignore(p)]
    except PermissionError:
        return []
    entries.sort(key=lambda p: (not p.is_dir(), p.name.lower()))
    return entries


def get_file_size(path: Path) -> Union[int, None]:
    """
    Return the size in bytes for the file at path.
    If size cannot be determined (permission/IO error), return None.
    """
    try:
        # Use stat() for efficiency
        st = path.stat()
        return st.st_size
    except (OSError, PermissionError):
        return None


def write_tree(
    root: Path,
    out_file,
    prefix: str = "",
    depth: Optional[int] = None
) -> None:
    """
    Write the tree representation of `root` to open file `out_file`.

    - prefix: string used before each entry (manages vertical lines/spacing)
    - depth: remaining depth to recurse; None means unlimited
    """
    entries = iter_entries(root)
    count = len(entries)
    for idx, entry in enumerate(entries):
        is_last = idx == (count - 1)
        connector = LAST if is_last else BRANCH

        # Prepare display name: add size for files only
        display_name = entry.name
        if entry.is_file():
            size = get_file_size(entry)
            if size is None:
                display_name = f"{display_name} (?: bytes)"
            else:
                display_name = f"{display_name} ({size} bytes)"

        out_file.write(f"{prefix}{connector}{display_name}\n")

        # Recurse only into non-ignored directories
        if entry.is_dir() and not should_ignore(entry) and (depth is None or depth > 1):
            extension = "    " if is_last else INDENT
            next_depth = None if depth is None else depth - 1
            write_tree(entry, out_file, prefix + extension, next_depth)


def make_tree(root: Path, out_path: Path, max_depth: Optional[int] = None) -> None:
    """
    Create a text file at out_path containing the tree for root.
    """
    with out_path.open("w", encoding="utf-8") as f:
        header = f"{root.name if root.name else str(root)}/\n"
        f.write(header)
        write_tree(root, f, prefix="", depth=max_depth)


def main():
    raw = input("Enter folder path (leave empty for current directory): ").strip()
    if not raw:
        raw = "."
    root = Path(raw).expanduser().resolve()
    if not root.exists() or not root.is_dir():
        print(f"Error: '{root}' is not a valid directory.", file=sys.stderr)
        return

    out_name = input("Output file name (leave empty for 'folder_structure.txt'): ").strip()
    if not out_name:
        out_name = "folder_structure.txt"
    out_path = Path(out_name)

    depth_input = input("Max depth (leave empty for unlimited): ").strip()
    if depth_input:
        try:
            max_depth = int(depth_input)
            if max_depth < 1:
                raise ValueError
        except ValueError:
            print("Invalid max depth. Using unlimited depth.", file=sys.stderr)
            max_depth = None
    else:
        max_depth = None

    make_tree(root, out_path, max_depth)
    print(f"Folder structure saved to: {out_path}")


if __name__ == "__main__":
    main()